import { useState } from 'react';
import { Search, Play, RefreshCw, Table, Filter, X } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import Button from '../ui/Button';
import Input from '../ui/Input';
import Select from '../ui/Select';
import { QueryResult } from '../../types';
import { MOCK_TABLES, MOCK_FIELDS } from '../../data/mockData';
import { loadFromLocalStorage } from '../../utils/helpers';

export default function QueryAnalysisPage() {
  const [selectedTable, setSelectedTable] = useState('');
  const [limit, setLimit] = useState(100);
  const [whereClause, setWhereClause] = useState('');
  const [orderBy, setOrderBy] = useState('');
  const [orderDirection, setOrderDirection] = useState<'ASC' | 'DESC'>('DESC');
  const [selectedFields, setSelectedFields] = useState<string[]>([]);
  const [result, setResult] = useState<QueryResult | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);
  const [queryHistory, setQueryHistory] = useState<Array<{ query: string; time: string }>>([]);

  const demoMode = loadFromLocalStorage<boolean>('demo_mode', false);
  const availableFields = selectedTable ? MOCK_FIELDS[selectedTable] || [] : [];

  const handleExecuteQuery = async () => {
    setIsExecuting(true);
    setResult(null);

    await new Promise(resolve => setTimeout(resolve, 500 + Math.random() * 500));

    const fields = selectedFields.length > 0 ? selectedFields : availableFields;
    const mockData = generateMockData(fields, limit);

    setResult({
      data: mockData,
      duration: Math.floor(Math.random() * 200) + 50,
      rowCount: mockData.length,
    });

    const query = buildQuery();
    setQueryHistory(prev => [{ query, time: new Date().toLocaleTimeString() }, ...prev.slice(0, 9)]);

    setIsExecuting(false);
  };

  const buildQuery = () => {
    const fields = selectedFields.length > 0 ? selectedFields.join(', ') : '*';
    let query = `SELECT ${fields} FROM ${selectedTable}`;

    if (whereClause) {
      query += ` WHERE ${whereClause}`;
    }

    if (orderBy) {
      query += ` ORDER BY ${orderBy} ${orderDirection}`;
    }

    query += ` LIMIT ${limit}`;

    return query;
  };

  const generateMockData = (fields: string[], rowLimit: number) => {
    const data: Array<{ [key: string]: string | number }> = [];

    for (let i = 0; i < rowLimit; i++) {
      const row: { [key: string]: string | number } = {};
      fields.forEach((field) => {
        if (field.toLowerCase().includes('id')) {
          row[field] = `id-${i + 1}`;
        } else if (field.toLowerCase().includes('time') || field.toLowerCase().includes('date')) {
          row[field] = new Date(Date.now() - Math.random() * 86400000 * 30).toISOString();
        } else if (field.toLowerCase().includes('count') || field.toLowerCase().includes('value')) {
          row[field] = Math.floor(Math.random() * 1000);
        } else if (field.toLowerCase().includes('status') || field.toLowerCase().includes('level')) {
          const statuses = ['success', 'error', 'warning', 'info'];
          row[field] = statuses[Math.floor(Math.random() * statuses.length)];
        } else if (field.toLowerCase().includes('ip')) {
          row[field] = `192.168.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;
        } else if (field.toLowerCase().includes('user')) {
          row[field] = `user_${Math.floor(Math.random() * 100)}`;
        } else {
          row[field] = `value_${Math.floor(Math.random() * 100)}`;
        }
      });
      data.push(row);
    }

    return data;
  };

  const toggleField = (field: string) => {
    setSelectedFields(prev =>
      prev.includes(field)
        ? prev.filter(f => f !== field)
        : [...prev, field]
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">数据查询</h1>
        <p className="text-gray-600 mt-2">查询 ClickHouse 数据库中的数据</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Query Builder */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5 text-blue-600" />
              查询配置
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Select
              label="数据表"
              value={selectedTable}
              onChange={(e) => {
                setSelectedTable(e.target.value);
                setSelectedFields([]);
                setOrderBy('');
              }}
              options={[
                { value: '', label: '选择数据表' },
                ...MOCK_TABLES.map(t => ({ value: t, label: t })),
              ]}
            />

            {/* Field Selection */}
            {selectedTable && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  查询字段
                </label>
                <div className="space-y-2 max-h-48 overflow-y-auto border border-gray-200 rounded-lg p-2">
                  {availableFields.map((field) => (
                    <label key={field} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-1 rounded">
                      <input
                        type="checkbox"
                        checked={selectedFields.includes(field)}
                        onChange={() => toggleField(field)}
                        className="w-4 h-4 rounded border-gray-300"
                      />
                      <span className="text-sm text-gray-700">{field}</span>
                    </label>
                  ))}
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  已选择 {selectedFields.length} / {availableFields.length} 个字段
                </p>
              </div>
            )}

            <Input
              label="WHERE 条件"
              placeholder="如: status = 'error'"
              value={whereClause}
              onChange={(e) => setWhereClause(e.target.value)}
            />

            <div className="grid grid-cols-2 gap-3">
              <Select
                label="排序字段"
                value={orderBy}
                onChange={(e) => setOrderBy(e.target.value)}
                options={[
                  { value: '', label: '无排序' },
                  ...availableFields.map(f => ({ value: f, label: f })),
                ]}
                disabled={!selectedTable}
              />

              <Select
                label="排序方向"
                value={orderDirection}
                onChange={(e) => setOrderDirection(e.target.value as 'ASC' | 'DESC')}
                options={[
                  { value: 'DESC', label: '降序' },
                  { value: 'ASC', label: '升序' },
                ]}
              />
            </div>

            <Input
              label="返回行数"
              type="number"
              value={limit}
              onChange={(e) => setLimit(parseInt(e.target.value) || 100)}
              min={1}
              max={10000}
            />

            {/* SQL Preview */}
            {selectedTable && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  SQL 预览
                </label>
                <pre className="bg-gray-800 text-green-400 p-3 rounded-lg text-xs font-mono overflow-x-auto">
                  {buildQuery()}
                </pre>
              </div>
            )}

            <Button
              onClick={handleExecuteQuery}
              disabled={isExecuting || !selectedTable}
              className="w-full"
              size="lg"
            >
              {isExecuting ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  执行中...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  执行查询
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Results */}
        <div className="lg:col-span-3 space-y-6">
          {/* Stats */}
          {result && (
            <div className="grid grid-cols-3 gap-4">
              <Card>
                <CardContent className="pt-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">查询耗时</p>
                      <p className="text-2xl font-bold text-gray-900">{result.duration} ms</p>
                    </div>
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Search className="w-5 h-5 text-blue-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">返回行数</p>
                      <p className="text-2xl font-bold text-gray-900">{result.rowCount}</p>
                    </div>
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                      <Table className="w-5 h-5 text-green-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">数据表</p>
                      <p className="text-2xl font-bold text-gray-900 font-mono text-lg">{selectedTable}</p>
                    </div>
                    <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                      <Table className="w-5 h-5 text-purple-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Query History */}
          {queryHistory.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>查询历史</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {queryHistory.slice(0, 5).map((item, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-sm">
                      <span className="text-gray-600 font-mono">{item.time}</span>
                      <pre className="flex-1 bg-gray-800 text-green-400 p-2 rounded text-xs font-mono overflow-x-auto">
                        {item.query}
                      </pre>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Data Table */}
          {result && (
            <Card>
              <CardHeader>
                <CardTitle>查询结果</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-200 bg-gray-50">
                        <th className="text-left py-2 px-3 text-xs font-semibold text-gray-600">#</th>
                        {Object.keys(result.data[0] || {}).map((key) => (
                          <th key={key} className="text-left py-2 px-3 text-xs font-semibold text-gray-600">
                            {key}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {result.data.slice(0, 50).map((row, index) => (
                        <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                          <td className="py-2 px-3 text-xs text-gray-600">{index + 1}</td>
                          {Object.entries(row).map(([key, value]) => (
                            <td key={key} className="py-2 px-3 text-xs text-gray-900 font-mono max-w-xs truncate">
                              {String(value)}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Empty State */}
          {!result && !isExecuting && (
            <Card>
              <CardContent className="py-16">
                <div className="text-center">
                  <Search className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-600">选择数据表后点击"执行查询"</p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Loading State */}
          {isExecuting && (
            <Card>
              <CardContent className="py-16">
                <div className="text-center">
                  <RefreshCw className="w-16 h-16 text-blue-500 mx-auto mb-4 animate-spin" />
                  <p className="text-gray-600">正在执行查询...</p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
