import { useState, useEffect } from 'react';
import { RefreshCw, X, Check, AlertCircle, AlertTriangle, Book, History, Lightbulb } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import Button from '../ui/Button';
import Select from '../ui/Select';
import { Alert, Severity, AlertStatus, ResolutionMethod } from '../../types';
import { generateMockAlerts, DEFAULT_RESOLUTION_METHODS } from '../../data/mockData';
import { getSeverityColor, getSeverityText, getStatusColor, getStatusText, formatDateTime } from '../../utils/helpers';

const SEVERITY_OPTIONS: Array<{ value: Severity; label: string }> = [
  { value: 'critical', label: '紧急' },
  { value: 'high', label: '高' },
  { value: 'medium', label: '中' },
  { value: 'low', label: '低' },
  { value: 'info', label: '信息' },
];

export default function AlertManagementPage() {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [filteredAlerts, setFilteredAlerts] = useState<Alert[]>([]);
  const [selectedAlert, setSelectedAlert] = useState<Alert | null>(null);
  const [resolutionMethods] = useState<ResolutionMethod[]>(() => {
    return DEFAULT_RESOLUTION_METHODS.map((method, index) => ({
      ...method,
      id: `method-${index + 1}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }));
  });
  const [alertFilter, setAlertFilter] = useState<'all' | AlertStatus>('all');
  const [severityFilter, setSeverityFilter] = useState<'all' | Severity>('all');
  const [isDetecting, setIsDetecting] = useState(false);
  const [matchHistory, setMatchHistory] = useState<Alert[]>([]);
  const [editingSuggestion, setEditingSuggestion] = useState<string>('');

  useEffect(() => {
    const mockAlerts = generateMockAlerts(50);
    setAlerts(mockAlerts);
  }, []);

  useEffect(() => {
    filterAlerts();
  }, [alerts, alertFilter, severityFilter]);

  const filterAlerts = () => {
    let filtered = alerts;
    if (alertFilter !== 'all') {
      filtered = filtered.filter(a => a.status === alertFilter);
    }
    if (severityFilter !== 'all') {
      filtered = filtered.filter(a => a.severity === severityFilter);
    }
    setFilteredAlerts(filtered);
  };

  const handleDetectAlerts = async () => {
    setIsDetecting(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    const newAlerts = generateMockAlerts(Math.floor(Math.random() * 10) + 3);
    setAlerts(prev => [...newAlerts, ...prev]);
    setIsDetecting(false);
  };

  const handleAlertAction = (alertId: string, action: 'acknowledged' | 'resolved' | 'suppressed', methodId?: string) => {
    setAlerts(prev =>
      prev.map(a =>
        a.id === alertId
          ? {
              ...a,
              status: action,
              resolved_at: action === 'resolved' ? new Date().toISOString() : a.resolved_at,
              resolution_method_id: methodId || a.resolution_method_id,
            }
          : a
      )
    );

    if (selectedAlert && selectedAlert.id === alertId) {
      setSelectedAlert({
        ...selectedAlert,
        status: action,
        resolved_at: action === 'resolved' ? new Date().toISOString() : selectedAlert.resolved_at,
        resolution_method_id: methodId || selectedAlert.resolution_method_id,
      });
    }
  };

  const handleUpdateSuggestion = (alertId: string, suggestion: string) => {
    setAlerts(prev =>
      prev.map(a =>
        a.id === alertId
          ? { ...a, resolution_suggestion: suggestion }
          : a
      )
    );

    if (selectedAlert && selectedAlert.id === alertId) {
      setSelectedAlert({
        ...selectedAlert,
        resolution_suggestion: suggestion,
      });
    }
  };

  const findMatchingHistory = (alert: Alert): Alert[] => {
    return alerts.filter(a =>
      a.id !== alert.id &&
      a.status === 'resolved' &&
      a.alert_type === alert.alert_type
    ).slice(0, 3);
  };

  const findMatchingMethods = (alert: Alert): ResolutionMethod[] => {
    return resolutionMethods.filter(method =>
      method.alert_type === alert.alert_type ||
      method.severity_range.includes(alert.severity)
    );
  };

  const handleViewAlert = (alert: Alert) => {
    const history = findMatchingHistory(alert);
    setMatchHistory(history);
    setSelectedAlert(alert);
    setEditingSuggestion(alert.resolution_suggestion);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">告警管理</h1>
          <p className="text-gray-600 mt-2">查看和处理系统告警</p>
        </div>
        <Button onClick={handleDetectAlerts} disabled={isDetecting} size="lg">
          {isDetecting ? (
            <>
              <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
              检测中...
            </>
          ) : (
            <>
              <AlertTriangle className="w-4 h-4 mr-2" />
              检测告警
            </>
          )}
        </Button>
      </div>

      {/* Alerts Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>告警列表 ({filteredAlerts.length})</CardTitle>
            <div className="flex items-center gap-3">
              <Select
                value={alertFilter}
                onChange={(e) => setAlertFilter(e.target.value as 'all' | AlertStatus)}
                options={[
                  { value: 'all', label: '全部状态' },
                  { value: 'active', label: '活跃' },
                  { value: 'acknowledged', label: '已确认' },
                  { value: 'resolved', label: '已解决' },
                ]}
              />
              <Select
                value={severityFilter}
                onChange={(e) => setSeverityFilter(e.target.value as 'all' | Severity)}
                options={[
                  { value: 'all', label: '全部级别' },
                  ...SEVERITY_OPTIONS,
                ]}
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">严重程度</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">告警类型</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">状态</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">内容</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">处置建议</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">触发时间</th>
                  <th className="text-right py-3 px-4 text-sm font-semibold text-gray-600">操作</th>
                </tr>
              </thead>
              <tbody>
                {filteredAlerts.slice(0, 20).map((alert) => (
                  <tr key={alert.id} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <span
                        className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium"
                        style={{ backgroundColor: getSeverityColor(alert.severity) + '20', color: getSeverityColor(alert.severity) }}
                      >
                        {getSeverityText(alert.severity)}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-sm text-gray-900">{alert.alert_type}</td>
                    <td className="py-3 px-4">
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(alert.status)}`}>
                        {getStatusText(alert.status)}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-sm text-gray-600 max-w-xs truncate">{alert.content}</td>
                    <td className="py-3 px-4">
                      <div className="max-w-xs">
                        <p className="text-xs text-gray-600 truncate">{alert.resolution_suggestion || '-'}</p>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-sm text-gray-600">{formatDateTime(alert.triggered_at)}</td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        {alert.status === 'active' && (
                          <>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleAlertAction(alert.id, 'acknowledged')}
                              title="确认"
                            >
                              <Check className="w-4 h-4 text-yellow-600" />
                            </Button>
                          </>
                        )}
                        <Button variant="ghost" size="sm" onClick={() => handleViewAlert(alert)}>
                          详情
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Alert Detail Modal */}
      {selectedAlert && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full my-8">
            <div className="sticky top-0 bg-white px-6 py-4 border-b border-gray-200 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <AlertCircle className="w-6 h-6 text-red-600" />
                <h2 className="text-xl font-bold text-gray-900">告警详情</h2>
              </div>
              <button onClick={() => setSelectedAlert(null)} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
              {/* Alert Info */}
              <div className="flex items-center gap-4">
                <span
                  className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium"
                  style={{ backgroundColor: getSeverityColor(selectedAlert.severity) + '20', color: getSeverityColor(selectedAlert.severity) }}
                >
                  {getSeverityText(selectedAlert.severity)}
                </span>
                <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(selectedAlert.status)}`}>
                  {getStatusText(selectedAlert.status)}
                </span>
                <span className="text-sm text-gray-600">{selectedAlert.alert_type}</span>
              </div>

              <Card>
                <CardContent className="pt-4 space-y-3">
                  <div>
                    <p className="text-sm text-gray-600">告警内容</p>
                    <p className="text-gray-900 mt-1">{selectedAlert.content}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-600">触发时间</p>
                      <p className="text-gray-900 mt-1">{formatDateTime(selectedAlert.triggered_at)}</p>
                    </div>
                    {selectedAlert.resolved_at && (
                      <div>
                        <p className="text-sm text-gray-600">解决时间</p>
                        <p className="text-gray-900 mt-1">{formatDateTime(selectedAlert.resolved_at)}</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Editable Resolution Suggestion */}
              <Card className="bg-blue-50 border-blue-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-blue-900">
                    <Lightbulb className="w-5 h-5" />
                    处置建议
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <textarea
                    value={editingSuggestion}
                    onChange={(e) => setEditingSuggestion(e.target.value)}
                    onBlur={() => handleUpdateSuggestion(selectedAlert.id, editingSuggestion)}
                    className="w-full p-3 border border-blue-300 rounded-lg text-sm text-blue-900 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                    rows={5}
                    placeholder="输入处置建议..."
                  />
                  <p className="text-xs text-blue-700 mt-2">可编辑此处置建议，点击其他区域自动保存</p>
                </CardContent>
              </Card>

              {/* Matching Methods */}
              {selectedAlert.status === 'active' && findMatchingMethods(selectedAlert).length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Book className="w-5 h-5 text-green-600" />
                      推荐处置方法
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {findMatchingMethods(selectedAlert).map((method) => (
                      <div key={method.id} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="font-medium text-gray-900">{method.name}</h4>
                          <Button
                            variant="success"
                            size="sm"
                            onClick={() => handleAlertAction(selectedAlert.id, 'resolved', method.id)}
                          >
                            应用此方法
                          </Button>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">{method.description}</p>
                        <ol className="list-decimal list-inside space-y-1 text-sm text-gray-700">
                          {method.steps.slice(0, 3).map((step, idx) => (
                            <li key={idx}>{step}</li>
                          ))}
                        </ol>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              )}

              {/* Historical Matches */}
              {matchHistory.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <History className="w-5 h-5 text-purple-600" />
                      历史相似告警
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {matchHistory.map((historyAlert) => {
                      const method = resolutionMethods.find(m => m.id === historyAlert.resolution_method_id);
                      return (
                        <div key={historyAlert.id} className="border border-gray-200 rounded-lg p-3 bg-gray-50">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-medium text-gray-900">
                              {formatDateTime(historyAlert.triggered_at)}
                            </span>
                            <span className="text-xs text-gray-600">已解决</span>
                          </div>
                          {method && (
                            <div>
                              <p className="text-sm font-medium text-gray-700 mb-1">使用方法: {method.name}</p>
                              <ol className="list-decimal list-inside space-y-0.5 text-xs text-gray-600">
                                {method.steps.slice(0, 2).map((step, idx) => (
                                  <li key={idx}>{step}</li>
                                ))}
                              </ol>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </CardContent>
                </Card>
              )}

              {/* Actions */}
              {selectedAlert.status === 'active' && (
                <div className="space-y-3">
                  <p className="text-sm font-medium text-gray-700">快速操作</p>
                  <div className="flex gap-3">
                    <Button
                      variant="secondary"
                      onClick={() => handleAlertAction(selectedAlert.id, 'acknowledged')}
                    >
                      确认告警
                    </Button>
                    <Button
                      variant="success"
                      onClick={() => handleAlertAction(selectedAlert.id, 'resolved')}
                    >
                      解决告警
                    </Button>
                    <Button
                      variant="ghost"
                      onClick={() => handleAlertAction(selectedAlert.id, 'suppressed')}
                    >
                      抑制告警
                    </Button>
                  </div>
                </div>
              )}
            </div>

            <div className="sticky bottom-0 bg-gray-50 px-6 py-4 border-t border-gray-200">
              <Button variant="secondary" onClick={() => setSelectedAlert(null)}>
                关闭
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
