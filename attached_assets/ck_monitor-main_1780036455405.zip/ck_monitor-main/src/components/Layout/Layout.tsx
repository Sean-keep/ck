import { ReactNode, useState } from 'react';
import {
  Database, AlertTriangle, BarChart3, Settings, Activity, Book, FileText,
  ChevronLeft, ChevronRight, LogOut, User
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

interface LayoutProps {
  children: ReactNode;
  currentPage: string;
  onNavigate: (page: string) => void;
}

const navItems = [
  { id: 'dashboard', label: '监控概览', icon: Activity },
  { id: 'database', label: '数据库配置', icon: Database },
  { id: 'query', label: '数据查询', icon: BarChart3 },
  { id: 'alerts', label: '告警管理', icon: AlertTriangle },
  { id: 'rules', label: '告警规则', icon: FileText },
  { id: 'methods', label: '处置方法', icon: Book },
  { id: 'settings', label: '设置', icon: Settings },
];

export default function Layout({ children, currentPage, onNavigate }: LayoutProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const { user, logout } = useAuth();

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <aside
        className={`${
          isCollapsed ? 'w-20' : 'w-64'
        } bg-gradient-to-b from-slate-900 to-slate-800 text-white flex flex-col transition-all duration-300`}
      >
        {/* Header */}
        <div className={`px-${isCollapsed ? '3' : '6'} py-6 border-b border-slate-700`}>
          <div className={`flex items-center ${isCollapsed ? 'justify-center' : 'gap-3'}`}>
            <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
              <Activity className="w-6 h-6" />
            </div>
            {!isCollapsed && (
              <div>
                <h1 className="text-lg font-bold">ClickHouse</h1>
                <p className="text-xs text-slate-400">Monitor System</p>
              </div>
            )}
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-4 overflow-y-auto">
          <ul className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              return (
                <li key={item.id}>
                  <button
                    onClick={() => onNavigate(item.id)}
                    className={`w-full flex items-center ${isCollapsed ? 'justify-center' : 'gap-3'} px-4 py-3 rounded-lg transition-all group ${
                      isActive
                        ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-lg'
                        : 'text-slate-300 hover:bg-slate-700 hover:text-white'
                    }`}
                    title={isCollapsed ? item.label : ''}
                  >
                    <Icon className="w-5 h-5 flex-shrink-0" />
                    {!isCollapsed && <span className="font-medium">{item.label}</span>}
                    {isCollapsed && !isActive && (
                      <div className="absolute left-full ml-6 px-2 py-1 bg-slate-800 text-white text-sm rounded opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50">
                        {item.label}
                      </div>
                    )}
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Collapse Toggle */}
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="mx-3 mb-3 p-2 bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center justify-center transition-all"
        >
          {isCollapsed ? (
            <ChevronRight className="w-5 h-5" />
          ) : (
            <ChevronLeft className="w-5 h-5" />
          )}
        </button>

        {/* User Info */}
        <div className="px-3 py-4 border-t border-slate-700">
          <div className={`px-4 py-3 bg-slate-800 rounded-lg ${isCollapsed ? 'justify-center' : ''}`}>
            {isCollapsed ? (
              <div className="flex justify-center">
                <User className="w-5 h-5" />
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-slate-400" />
                    <span className="text-sm text-white">{user?.username}</span>
                  </div>
                  <button
                    onClick={logout}
                    className="text-slate-400 hover:text-red-400 transition-colors"
                    title="退出登录"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              </>
            )}
          </div>
        </div>

        {/* System Status */}
        {!isCollapsed && (
          <div className="px-3 py-4 border-t border-slate-700">
            <div className="px-4 py-3 bg-slate-800 rounded-lg">
              <p className="text-xs text-slate-400 mb-1">系统状态</p>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                <span className="text-sm text-white">运行正常</span>
              </div>
            </div>
          </div>
        )}
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        {children}
      </main>
    </div>
  );
}
