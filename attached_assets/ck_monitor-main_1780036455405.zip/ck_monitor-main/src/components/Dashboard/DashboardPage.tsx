import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { AlertTriangle, TrendingUp, Activity, CheckCircle, Bell, Settings, FileText } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { generateAlertTrendData, generateSeverityDistribution, generateMockAlerts, DEFAULT_RULES, DEFAULT_RESOLUTION_METHODS } from '../../data/mockData';
import { useEffect, useState } from 'react';
import { Severity, Alert } from '../../types';
import { formatTime, getSeverityText, getSeverityColor } from '../../utils/helpers';

export default function DashboardPage() {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [trendData, setTrendData] = useState<{ time: string; count: number }[]>([]);
  const [severityDist, setSeverityDist] = useState<{ [key in Severity]: number } | null>(null);
  const [stats, setStats] = useState({
    active: 0,
    total: 0,
    critical: 0,
    high: 0,
    medium: 0,
    low: 0,
    info: 0,
    rules: DEFAULT_RULES.length,
    methods: DEFAULT_RESOLUTION_METHODS.length,
    acknowledged: 0,
    resolved: 0,
  });

  useEffect(() => {
    setTrendData(generateAlertTrendData());
    setSeverityDist(generateSeverityDistribution());
    const mockAlerts = generateMockAlerts(50);
    setAlerts(mockAlerts);

    const severityCount = {
      critical: mockAlerts.filter(a => a.severity === 'critical').length,
      high: mockAlerts.filter(a => a.severity === 'high').length,
      medium: mockAlerts.filter(a => a.severity === 'medium').length,
      low: mockAlerts.filter(a => a.severity === 'low').length,
      info: mockAlerts.filter(a => a.severity === 'info').length,
    };

    setStats({
      active: mockAlerts.filter(a => a.status === 'active').length,
      total: mockAlerts.length,
      ...severityCount,
      rules: DEFAULT_RULES.length,
      methods: DEFAULT_RESOLUTION_METHODS.length,
      acknowledged: mockAlerts.filter(a => a.status === 'acknowledged').length,
      resolved: mockAlerts.filter(a => a.status === 'resolved').length,
    });
  }, []);

  const pieData = severityDist ? Object.entries(severityDist).map(([severity, count]) => ({
    name: getSeverityText(severity as Severity),
    value: count,
    severity: severity as Severity,
  })) : [];

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">监控概览</h1>
        <p className="text-gray-600 mt-2">ClickHouse 告警监控系统实时仪表盘</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-6">
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-600">活跃告警</p>
                <p className="text-2xl font-bold text-red-600">{stats.active}</p>
              </div>
              <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-600">总告警数</p>
                <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
              </div>
              <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                <Bell className="w-5 h-5 text-gray-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-600">已确认</p>
                <p className="text-2xl font-bold text-yellow-600">{stats.acknowledged}</p>
              </div>
              <div className="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center">
                <Activity className="w-5 h-5 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-600">已解决</p>
                <p className="text-2xl font-bold text-green-600">{stats.resolved}</p>
              </div>
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle className="w-5 h-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-600">告警规则</p>
                <p className="text-2xl font-bold text-blue-600">{stats.rules}</p>
              </div>
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <FileText className="w-5 h-5 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-600">处置方法</p>
                <p className="text-2xl font-bold text-purple-600">{stats.methods}</p>
              </div>
              <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                <Settings className="w-5 h-5 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Severity Distribution */}
      <div className="grid grid-cols-5 gap-4 mb-6">
        {(['critical', 'high', 'medium', 'low', 'info'] as Severity[]).map((severity) => (
          <Card key={severity}>
            <CardContent className="pt-4">
              <div className="text-center">
                <div
                  className="inline-flex items-center justify-center w-12 h-12 rounded-full mb-2"
                  style={{ backgroundColor: getSeverityColor(severity) + '20' }}
                >
                  <span
                    className="text-xl font-bold"
                    style={{ color: getSeverityColor(severity) }}
                  >
                    {stats[severity]}
                  </span>
                </div>
                <p className="text-sm font-medium text-gray-700">{getSeverityText(severity)}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>24小时告警趋势</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="time" stroke="#6b7280" fontSize={12} />
                  <YAxis stroke="#6b7280" fontSize={12} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
                  />
                  <Line
                    type="monotone"
                    dataKey="count"
                    stroke="#f97316"
                    strokeWidth={2}
                    dot={{ fill: '#f97316', strokeWidth: 2 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>告警严重程度分布</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={getSeverityColor(entry.severity)} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Status Distribution Bar Chart */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>告警状态分布</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={[
                  { name: '活跃', value: stats.active, color: '#ef4444' },
                  { name: '已确认', value: stats.acknowledged, color: '#f59e0b' },
                  { name: '已解决', value: stats.resolved, color: '#10b981' },
                ]}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="name" stroke="#6b7280" fontSize={12} />
                <YAxis stroke="#6b7280" fontSize={12} />
                <Tooltip />
                <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                  <Cell fill="#ef4444" />
                  <Cell fill="#f59e0b" />
                  <Cell fill="#10b981" />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Recent Alerts */}
      <Card>
        <CardHeader>
          <CardTitle>最近告警</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">严重程度</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">告警类型</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">状态</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">内容</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">触发时间</th>
                </tr>
              </thead>
              <tbody>
                {alerts.slice(0, 10).map((alert) => (
                  <tr key={alert.id} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <span
                        className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium"
                        style={{ backgroundColor: getSeverityColor(alert.severity) + '20', color: getSeverityColor(alert.severity) }}
                      >
                        {getSeverityText(alert.severity)}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-sm text-gray-900">{alert.alert_type}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                          alert.status === 'active' ? 'bg-red-100 text-red-700' :
                          alert.status === 'acknowledged' ? 'bg-yellow-100 text-yellow-700' :
                          alert.status === 'resolved' ? 'bg-green-100 text-green-700' :
                          'bg-gray-100 text-gray-700'
                        }`}
                      >
                        {alert.status === 'active' ? '活跃' :
                         alert.status === 'acknowledged' ? '已确认' :
                         alert.status === 'resolved' ? '已解决' : '已抑制'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-sm text-gray-600 max-w-md truncate">{alert.content}</td>
                    <td className="py-3 px-4 text-sm text-gray-600">{formatTime(alert.triggered_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
