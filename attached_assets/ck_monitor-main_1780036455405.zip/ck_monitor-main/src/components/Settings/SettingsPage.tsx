import { Settings as SettingsIcon, Moon, Sun, Monitor } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import Toggle from '../ui/Toggle';
import { useState } from 'react';

export default function SettingsPage() {
  const [notifications, setNotifications] = useState(true);
  const [autoDetect, setAutoDetect] = useState(false);
  const [soundAlerts, setSoundAlerts] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">设置</h1>
          <p className="text-gray-600 mt-2">管理系统配置和偏好设置</p>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>通知设置</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Toggle
                checked={notifications}
                onChange={setNotifications}
                label="浏览器通知"
                description="当有新告警时发送浏览器通知"
              />

              <div className="border-t border-gray-200 pt-4">
                <Toggle
                  checked={soundAlerts}
                  onChange={setSoundAlerts}
                  label="声音提示"
                  description="告警时播放提示音"
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>自动化设置</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Toggle
                checked={autoDetect}
                onChange={setAutoDetect}
                label="自动检测"
                description="每5分钟自动检测一次告警"
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>关于</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm text-gray-600">
                <p><strong>系统名称：</strong>ClickHouse Monitor</p>
                <p><strong>版本：</strong>1.0.0</p>
                <p><strong>描述：</strong>ClickHouse 数据库监控与告警系统</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
