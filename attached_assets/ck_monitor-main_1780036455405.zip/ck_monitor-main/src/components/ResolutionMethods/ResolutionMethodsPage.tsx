import { useState } from 'react';
import { Plus, Book, X, Trash2, Edit, Search, CheckCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import Button from '../ui/Button';
import Input from '../ui/Input';
import Select from '../ui/Select';
import { ResolutionMethod, Severity } from '../../types';
import { DEFAULT_RESOLUTION_METHODS } from '../../data/mockData';
import { getSeverityColor, getSeverityText } from '../../utils/helpers';

const SEVERITY_OPTIONS: Array<{ value: Severity; label: string }> = [
  { value: 'critical', label: '紧急' },
  { value: 'high', label: '高' },
  { value: 'medium', label: '中' },
  { value: 'low', label: '低' },
  { value: 'info', label: '信息' },
];

export default function ResolutionMethodsPage() {
  const [methods, setMethods] = useState<ResolutionMethod[]>(() => {
    return DEFAULT_RESOLUTION_METHODS.map((method, index) => ({
      ...method,
      id: `method-${index + 1}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }));
  });
  const [showModal, setShowModal] = useState(false);
  const [editingMethod, setEditingMethod] = useState<ResolutionMethod | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [methodForm, setMethodForm] = useState<{
    name: string;
    description: string;
    alert_type: string;
    severity_range: Severity[];
    steps: string[];
    tags: string[];
  }>({
    name: '',
    description: '',
    alert_type: '',
    severity_range: [],
    steps: [''],
    tags: [],
  });

  const filteredMethods = methods.filter(method =>
    method.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    method.alert_type.toLowerCase().includes(searchTerm.toLowerCase()) ||
    method.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleSaveMethod = () => {
    if (!methodForm.name || !methodForm.alert_type || methodForm.steps.length === 0) {
      alert('请填写必要字段');
      return;
    }

    const validSteps = methodForm.steps.filter(s => s.trim() !== '');

    if (editingMethod) {
      setMethods(prev =>
        prev.map(m =>
          m.id === editingMethod.id
            ? {
                ...m,
                ...methodForm,
                steps: validSteps,
                updated_at: new Date().toISOString(),
              }
            : m
        )
      );
    } else {
      const newMethod: ResolutionMethod = {
        ...methodForm,
        steps: validSteps,
        id: `method-${Date.now()}`,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      setMethods(prev => [...prev, newMethod]);
    }

    setShowModal(false);
    setEditingMethod(null);
    setMethodForm({
      name: '',
      description: '',
      alert_type: '',
      severity_range: [],
      steps: [''],
      tags: [],
    });
  };

  const handleDeleteMethod = (methodId: string) => {
    if (confirm('确定删除该处置方法吗？')) {
      setMethods(prev => prev.filter(m => m.id !== methodId));
    }
  };

  const openEditModal = (method: ResolutionMethod) => {
    setEditingMethod(method);
    setMethodForm({
      name: method.name,
      description: method.description,
      alert_type: method.alert_type,
      severity_range: method.severity_range,
      steps: method.steps.length > 0 ? method.steps : [''],
      tags: method.tags,
    });
    setShowModal(true);
  };

  const openNewModal = () => {
    setEditingMethod(null);
    setMethodForm({
      name: '',
      description: '',
      alert_type: '',
      severity_range: [],
      steps: [''],
      tags: [],
    });
    setShowModal(true);
  };

  const addStep = () => {
    setMethodForm(prev => ({ ...prev, steps: [...prev.steps, ''] }));
  };

  const removeStep = (index: number) => {
    setMethodForm(prev => ({
      ...prev,
      steps: prev.steps.filter((_, i) => i !== index),
    }));
  };

  const updateStep = (index: number, value: string) => {
    setMethodForm(prev => ({
      ...prev,
      steps: prev.steps.map((s, i) => (i === index ? value : s)),
    }));
  };

  const toggleSeverity = (severity: Severity) => {
    setMethodForm(prev => ({
      ...prev,
      severity_range: prev.severity_range.includes(severity)
        ? prev.severity_range.filter(s => s !== severity)
        : [...prev.severity_range, severity],
    }));
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">处置方法</h1>
          <p className="text-gray-600 mt-2">管理告警处置的标准方法和流程</p>
        </div>
        <Button onClick={openNewModal} variant="success" size="lg">
          <Plus className="w-4 h-4 mr-2" />
          新建处置方法
        </Button>
      </div>

      {/* Search */}
      <Card className="mb-6">
        <CardContent className="pt-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="搜索处置方法名称、告警类型或标签..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </CardContent>
      </Card>

      {/* Methods Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredMethods.map((method) => (
          <Card key={method.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="flex items-center gap-2">
                    <Book className="w-5 h-5 text-blue-600" />
                    {method.name}
                  </CardTitle>
                  <p className="text-sm text-gray-600 mt-1">{method.description}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="sm" onClick={() => openEditModal(method)}>
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button variant="danger" size="sm" onClick={() => handleDeleteMethod(method.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <p className="text-sm font-medium text-gray-700">适用告警类型</p>
                  <p className="text-sm text-gray-900 mt-1">{method.alert_type}</p>
                </div>

                <div>
                  <p className="text-sm font-medium text-gray-700 mb-2">适用严重程度</p>
                  <div className="flex flex-wrap gap-2">
                    {method.severity_range.map((severity) => (
                      <span
                        key={severity}
                        className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium"
                        style={{ backgroundColor: getSeverityColor(severity) + '20', color: getSeverityColor(severity) }}
                      >
                        {getSeverityText(severity)}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <p className="text-sm font-medium text-gray-700 mb-2">处置步骤</p>
                  <ol className="list-decimal list-inside space-y-1">
                    {method.steps.map((step, index) => (
                      <li key={index} className="text-sm text-gray-600">{step}</li>
                    ))}
                  </ol>
                </div>

                <div>
                  <p className="text-sm font-medium text-gray-700 mb-2">标签</p>
                  <div className="flex flex-wrap gap-2">
                    {method.tags.map((tag, index) => (
                      <span
                        key={index}
                        className="inline-flex items-center px-2 py-1 rounded-lg text-xs bg-gray-100 text-gray-700"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredMethods.length === 0 && (
        <Card>
          <CardContent className="py-16">
            <div className="text-center">
              <Book className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600">没有找到匹配的处置方法</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full my-8">
            <div className="sticky top-0 bg-white px-6 py-4 border-b border-gray-200 flex items-center justify-between">
              <h2 className="text-xl font-bold text-gray-900">
                {editingMethod ? '编辑处置方法' : '新建处置方法'}
              </h2>
              <button onClick={() => setShowModal(false)} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
              <Input
                label="方法名称"
                value={methodForm.name}
                onChange={(e) => setMethodForm({ ...methodForm, name: e.target.value })}
                placeholder="如：暴力破解应急处置"
              />

              <Input
                label="方法描述"
                value={methodForm.description}
                onChange={(e) => setMethodForm({ ...methodForm, description: e.target.value })}
                placeholder="简要描述该处置方法的用途"
              />

              <Input
                label="适用告警类型"
                value={methodForm.alert_type}
                onChange={(e) => setMethodForm({ ...methodForm, alert_type: e.target.value })}
                placeholder="如：暴力破解登录检测"
              />

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  适用严重程度
                </label>
                <div className="flex flex-wrap gap-2">
                  {SEVERITY_OPTIONS.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => toggleSeverity(option.value)}
                      className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                        methodForm.severity_range.includes(option.value)
                          ? 'bg-blue-100 text-blue-700 border-2 border-blue-500'
                          : 'bg-gray-100 text-gray-700 border-2 border-transparent hover:bg-gray-200'
                      }`}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  处置步骤
                </label>
                <div className="space-y-2">
                  {methodForm.steps.map((step, index) => (
                    <div key={index} className="flex items-start gap-2">
                      <span className="inline-flex items-center justify-center w-8 h-10 bg-gray-100 rounded-lg text-sm font-medium text-gray-700">
                        {index + 1}
                      </span>
                      <Input
                        value={step}
                        onChange={(e) => updateStep(index, e.target.value)}
                        placeholder={`步骤 ${index + 1}`}
                        className="flex-1"
                      />
                      {methodForm.steps.length > 1 && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeStep(index)}
                          className="mt-1"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  ))}
                  <Button variant="secondary" onClick={addStep} className="w-full">
                    <Plus className="w-4 h-4 mr-2" />
                    添加步骤
                  </Button>
                </div>
              </div>

              <Input
                label="标签（用逗号分隔）"
                value={methodForm.tags.join(', ')}
                onChange={(e) => setMethodForm({ ...methodForm, tags: e.target.value.split(',').map(t => t.trim()).filter(t => t) })}
                placeholder="如：安全, 登录, 暴力破解, IP封禁"
                helpText="标签用于匹配和搜索处置方法"
              />
            </div>

            <div className="sticky bottom-0 bg-gray-50 px-6 py-4 border-t border-gray-200 flex items-center justify-end gap-3">
              <Button variant="secondary" onClick={() => setShowModal(false)}>
                取消
              </Button>
              <Button onClick={handleSaveMethod} variant="success">
                {editingMethod ? '保存更改' : '创建方法'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
