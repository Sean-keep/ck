import { useState, useEffect } from 'react';
import { Database, CheckCircle, XCircle, RefreshCw, Save } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import Button from '../ui/Button';
import Input from '../ui/Input';
import Toggle from '../ui/Toggle';
import { ClickHouseConnection } from '../../types';
import { saveToLocalStorage, loadFromLocalStorage } from '../../utils/helpers';

const DEFAULT_CONNECTION: ClickHouseConnection = {
  host: 'localhost',
  port: 8123,
  database: 'default',
  username: 'default',
  password: '',
};

export default function DatabaseConfigPage() {
  const [connection, setConnection] = useState<ClickHouseConnection>(DEFAULT_CONNECTION);
  const [demoMode, setDemoMode] = useState(false);
  const [isConnected, setIsConnected] = useState<boolean | null>(null);
  const [isTesting, setIsTesting] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [connectionMessage, setConnectionMessage] = useState('');

  useEffect(() => {
    const savedConnection = loadFromLocalStorage<ClickHouseConnection>('clickhouse_connection', DEFAULT_CONNECTION);
    const savedDemoMode = loadFromLocalStorage<boolean>('demo_mode', false);
    setConnection(savedConnection);
    setDemoMode(savedDemoMode);
  }, []);

  const handleTestConnection = async () => {
    setIsTesting(true);
    setConnectionMessage('');

    await new Promise(resolve => setTimeout(resolve, 1500));

    if (demoMode) {
      setIsConnected(true);
      setConnectionMessage('Demo模式连接成功（使用模拟数据）');
    } else {
      const success = Math.random() > 0.3;
      setIsConnected(success);
      setConnectionMessage(
        success
          ? '数据库连接成功'
          : '连接失败：无法连接到 ClickHouse 服务器，请检查配置'
      );
    }

    setIsTesting(false);
  };

  const handleSaveConfig = async () => {
    setIsSaving(true);

    saveToLocalStorage('clickhouse_connection', connection);
    saveToLocalStorage('demo_mode', demoMode);

    await new Promise(resolve => setTimeout(resolve, 500));

    setIsSaving(false);
  };

  const handleResetConfig = () => {
    setConnection(DEFAULT_CONNECTION);
    setIsConnected(null);
    setConnectionMessage('');
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">数据库配置</h1>
          <p className="text-gray-600 mt-2">配置 ClickHouse 连接信息并验证可用性</p>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5 text-blue-600" />
              演示模式
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Toggle
              checked={demoMode}
              onChange={(checked) => {
                setDemoMode(checked);
                setIsConnected(null);
              }}
              label="启用 Demo Mode"
              description="开启后使用模拟数据，无需真实数据库即可演示所有功能"
            />
          </CardContent>
        </Card>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle>连接配置</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label="服务地址 (Host)"
                placeholder="localhost"
                value={connection.host}
                onChange={(e) => setConnection({ ...connection, host: e.target.value })}
                disabled={demoMode}
              />

              <Input
                label="端口 (Port)"
                type="number"
                placeholder="8123"
                value={connection.port}
                onChange={(e) => setConnection({ ...connection, port: parseInt(e.target.value) || 8123 })}
                disabled={demoMode}
              />

              <Input
                label="数据库名"
                placeholder="default"
                value={connection.database}
                onChange={(e) => setConnection({ ...connection, database: e.target.value })}
                disabled={demoMode}
              />

              <Input
                label="用户名"
                placeholder="default"
                value={connection.username}
                onChange={(e) => setConnection({ ...connection, username: e.target.value })}
                disabled={demoMode}
              />

              <Input
                label="密码"
                type="password"
                placeholder="••••••••"
                value={connection.password}
                onChange={(e) => setConnection({ ...connection, password: e.target.value })}
                disabled={demoMode}
                className="md:col-span-2"
              />
            </div>
          </CardContent>
        </Card>

        {isConnected !== null && (
          <Card className={`mb-6 border-2 ${
            isConnected ? 'border-green-300 bg-green-50' : 'border-red-300 bg-red-50'
          }`}>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              {isConnected ? (
                <CheckCircle className="w-6 h-6 text-green-600" />
              ) : (
                <XCircle className="w-6 h-6 text-red-600" />
              )}
              <div>
                <p className={`font-semibold ${isConnected ? 'text-green-900' : 'text-red-900'}`}>
                  {isConnected ? '连接成功' : '连接失败'}
                </p>
                <p className={`text-sm ${isConnected ? 'text-green-700' : 'text-red-700'}`}>
                  {connectionMessage}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        )}

        <div className="flex items-center gap-4">
          <Button
            onClick={handleTestConnection}
            disabled={isTesting}
            size="lg"
            className="min-w-40"
          >
            {isTesting ? (
              <>
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                测试中...
              </>
            ) : (
              <>
                <Database className="w-4 h-4 mr-2" />
                测试连接
              </>
            )}
          </Button>

          <Button
            onClick={handleSaveConfig}
            disabled={isSaving}
            variant="success"
            size="lg"
            className="min-w-40"
          >
            {isSaving ? (
              <>
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                保存中...
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                保存配置
              </>
            )}
          </Button>

          <Button
            onClick={handleResetConfig}
            variant="secondary"
            size="lg"
          >
            重置配置
          </Button>
        </div>

        <div className="mt-8 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-sm text-blue-800">
            <strong>提示：</strong>配置信息将保存在浏览器本地存储中，刷新后自动加载。
            {demoMode && ' Demo模式已启用，无需真实数据库即可体验所有功能。'}
          </p>
        </div>
      </div>
    </div>
  );
}
