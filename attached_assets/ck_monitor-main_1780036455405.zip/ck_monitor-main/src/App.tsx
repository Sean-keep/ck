import { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Layout from './components/Layout/Layout';
import LoginPage from './components/Login/LoginPage';
import DashboardPage from './components/Dashboard/DashboardPage';
import DatabaseConfigPage from './components/DatabaseConfig/DatabaseConfigPage';
import QueryAnalysisPage from './components/QueryAnalysis/QueryAnalysisPage';
import AlertManagementPage from './components/AlertManagement/AlertManagementPage';
import AlertRulesPage from './components/AlertRules/AlertRulesPage';
import ResolutionMethodsPage from './components/ResolutionMethods/ResolutionMethodsPage';
import SettingsPage from './components/Settings/SettingsPage';

function AppContent() {
  const { user } = useAuth();
  const [currentPage, setCurrentPage] = useState('dashboard');

  if (!user?.isAuthenticated) {
    return <LoginPage />;
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'database':
        return <DatabaseConfigPage />;
      case 'query':
        return <QueryAnalysisPage />;
      case 'alerts':
        return <AlertManagementPage />;
      case 'rules':
        return <AlertRulesPage />;
      case 'methods':
        return <ResolutionMethodsPage />;
      case 'settings':
        return <SettingsPage />;
      case 'dashboard':
      default:
        return <DashboardPage />;
    }
  };

  return (
    <Layout currentPage={currentPage} onNavigate={setCurrentPage}>
      {renderPage()}
    </Layout>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
