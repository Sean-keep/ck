/*
  # 添加处置方法表和处置建议功能

  1. 新建表
    - `resolution_methods`: 处置方法库
      - id (uuid, 主键)
      - name (text, 方法名称)
      - description (text, 方法描述)
      - alert_type (text, 适用告警类型)
      - severity_range (text[], 适用严重程度范围)
      - steps (text, 处置步骤，JSON格式)
      - tags (text[], 标签，用于匹配)
      - created_at (timestamp, 创建时间)
      - updated_at (timestamp, 更新时间)

  2. 修改现有表
    - `alerts`: 添加字段
      - resolution_method_id (uuid, 关联处置方法)
      - resolution_suggestion (text, AI处置建议)
    
    - `alert_handling_history`: 添加字段
      - resolution_method_id (uuid, 关联处置方法)

  3. 安全
    - 启用 RLS
    - 添加访问策略
*/

-- 创建处置方法表
CREATE TABLE IF NOT EXISTS resolution_methods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text DEFAULT '',
  alert_type text DEFAULT '',
  severity_range text[] DEFAULT ARRAY[]::text[],
  steps text DEFAULT '[]',
  tags text[] DEFAULT ARRAY[]::text[],
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 为 alerts 表添加新字段
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'alerts' AND column_name = 'resolution_method_id'
  ) THEN
    ALTER TABLE alerts ADD COLUMN resolution_method_id uuid REFERENCES resolution_methods(id) ON DELETE SET NULL;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'alerts' AND column_name = 'resolution_suggestion'
  ) THEN
    ALTER TABLE alerts ADD COLUMN resolution_suggestion text DEFAULT '';
  END IF;
END $$;

-- 为 alert_handling_history 表添加新字段
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'alert_handling_history' AND column_name = 'resolution_method_id'
  ) THEN
    ALTER TABLE alert_handling_history ADD COLUMN resolution_method_id uuid REFERENCES resolution_methods(id) ON DELETE SET NULL;
  END IF;
END $$;

-- 启用 RLS
ALTER TABLE resolution_methods ENABLE ROW LEVEL SECURITY;

-- 添加访问策略
CREATE POLICY "Authenticated users can view resolution methods"
  ON resolution_methods FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert resolution methods"
  ON resolution_methods FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update resolution methods"
  ON resolution_methods FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete resolution methods"
  ON resolution_methods FOR DELETE
  TO authenticated
  USING (true);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_resolution_methods_alert_type ON resolution_methods(alert_type);
CREATE INDEX IF NOT EXISTS idx_alerts_resolution_method_id ON alerts(resolution_method_id);
CREATE INDEX IF NOT EXISTS idx_alert_handling_history_resolution_method_id ON alert_handling_history(resolution_method_id);