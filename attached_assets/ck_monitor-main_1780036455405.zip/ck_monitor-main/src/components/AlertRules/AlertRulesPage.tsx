import { useState } from 'react';
import { Plus, Settings, X, ToggleLeft, ToggleRight, Trash2, Edit } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import Button from '../ui/Button';
import Input from '../ui/Input';
import Select from '../ui/Select';
import Toggle from '../ui/Toggle';
import { AlertRule, RuleType, AggregationType, Operator, Severity } from '../../types';
import { DEFAULT_RULES, MOCK_TABLES, MOCK_FIELDS } from '../../data/mockData';
import { getSeverityColor, getSeverityText, formatDateTime } from '../../utils/helpers';

const SEVERITY_OPTIONS: Array<{ value: Severity; label: string }> = [
  { value: 'critical', label: '紧急' },
  { value: 'high', label: '高' },
  { value: 'medium', label: '中' },
  { value: 'low', label: '低' },
  { value: 'info', label: '信息' },
];

const RULE_TYPE_OPTIONS: Array<{ value: RuleType; label: string }> = [
  { value: 'threshold', label: '阈值规则' },
  { value: 'aggregation', label: '聚合规则' },
  { value: 'scenario', label: '场景规则' },
];

const AGGREGATION_OPTIONS: Array<{ value: AggregationType; label: string }> = [
  { value: 'COUNT', label: 'COUNT - 计数' },
  { value: 'SUM', label: 'SUM - 求和' },
  { value: 'AVG', label: 'AVG - 平均值' },
  { value: 'MIN', label: 'MIN - 最小值' },
  { value: 'MAX', label: 'MAX - 最大值' },
];

const OPERATOR_OPTIONS: Array<{ value: Operator; label: string }> = [
  { value: '>', label: '>' },
  { value: '<', label: '<' },
  { value: '>=', label: '>=' },
  { value: '<=', label: '<=' },
  { value: '==', label: '==' },
  { value: '!=', label: '!=' },
];

const defaultRuleForm: Omit<AlertRule, 'id' | 'created_at' | 'updated_at'> = {
  name: '',
  description: '',
  rule_type: 'threshold',
  table_name: '',
  group_by_field: '',
  aggregation_type: 'COUNT',
  operator: '>',
  threshold_value: 10,
  time_window_minutes: 5,
  severity: 'medium',
  alert_template: '',
  enabled: true,
};

export default function AlertRulesPage() {
  const [rules, setRules] = useState<AlertRule[]>(() => {
    return DEFAULT_RULES.map((rule, index) => ({
      ...rule,
      id: `rule-${index + 1}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }));
  });
  const [showRuleModal, setShowRuleModal] = useState(false);
  const [editingRule, setEditingRule] = useState<AlertRule | null>(null);
  const [ruleForm, setRuleForm] = useState(defaultRuleForm);

  const handleSaveRule = () => {
    if (!ruleForm.name || !ruleForm.table_name || !ruleForm.group_by_field) {
      alert('请填写必要字段');
      return;
    }

    if (editingRule) {
      setRules(prev =>
        prev.map(r =>
          r.id === editingRule.id
            ? { ...r, ...ruleForm, updated_at: new Date().toISOString() }
            : r
        )
      );
    } else {
      const newRule: AlertRule = {
        ...ruleForm,
        id: `rule-${Date.now()}`,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      setRules(prev => [...prev, newRule]);
    }

    setShowRuleModal(false);
    setEditingRule(null);
    setRuleForm(defaultRuleForm);
  };

  const handleDeleteRule = (ruleId: string) => {
    if (confirm('确定删除该规则吗？')) {
      setRules(prev => prev.filter(r => r.id !== ruleId));
    }
  };

  const handleToggleRule = (ruleId: string) => {
    setRules(prev =>
      prev.map(r =>
        r.id === ruleId ? { ...r, enabled: !r.enabled, updated_at: new Date().toISOString() } : r
      )
    );
  };

  const openEditRuleModal = (rule: AlertRule) => {
    setEditingRule(rule);
    setRuleForm(rule);
    setShowRuleModal(true);
  };

  const openNewRuleModal = () => {
    setEditingRule(null);
    setRuleForm(defaultRuleForm);
    setShowRuleModal(true);
  };

  const activeRules = rules.filter(r => r.enabled).length;
  const totalRules = rules.length;

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">告警规则</h1>
          <p className="text-gray-600 mt-2">管理系统中的所有告警检测规则</p>
        </div>
        <Button onClick={openNewRuleModal} variant="success" size="lg">
          <Plus className="w-4 h-4 mr-2" />
          新建规则
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">总规则数</p>
                <p className="text-3xl font-bold text-gray-900">{totalRules}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <Settings className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">已启用</p>
                <p className="text-3xl font-bold text-green-600">{activeRules}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <ToggleRight className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">已禁用</p>
                <p className="text-3xl font-bold text-gray-600">{totalRules - activeRules}</p>
              </div>
              <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center">
                <ToggleLeft className="w-6 h-6 text-gray-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Rules Table */}
      <Card>
        <CardHeader>
          <CardTitle>规则列表</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">规则名称</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">类型</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">数据表</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">条件</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">严重程度</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">状态</th>
                  <th className="text-right py-3 px-4 text-sm font-semibold text-gray-600">操作</th>
                </tr>
              </thead>
              <tbody>
                {rules.map((rule) => (
                  <tr key={rule.id} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-4 px-4">
                      <div>
                        <p className="font-medium text-gray-900">{rule.name}</p>
                        <p className="text-xs text-gray-500 mt-1">{rule.description}</p>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        rule.rule_type === 'threshold' ? 'bg-blue-100 text-blue-700' :
                        rule.rule_type === 'aggregation' ? 'bg-purple-100 text-purple-700' :
                        'bg-orange-100 text-orange-700'
                      }`}>
                        {rule.rule_type === 'threshold' ? '阈值' : rule.rule_type === 'aggregation' ? '聚合' : '场景'}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-sm text-gray-900 font-mono">{rule.table_name}</td>
                    <td className="py-4 px-4 text-sm text-gray-600">
                      <div>
                        <p className="font-mono">{rule.aggregation_type}({rule.group_by_field}) {rule.operator} {rule.threshold_value}</p>
                        <p className="text-xs text-gray-500 mt-1">时间窗口: {rule.time_window_minutes}分钟</p>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <span
                        className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium"
                        style={{ backgroundColor: getSeverityColor(rule.severity) + '20', color: getSeverityColor(rule.severity) }}
                      >
                        {getSeverityText(rule.severity)}
                      </span>
                    </td>
                    <td className="py-4 px-4">
                      <button
                        onClick={() => handleToggleRule(rule.id)}
                        className="focus:outline-none"
                      >
                        <Toggle checked={rule.enabled} onChange={() => {}} />
                      </button>
                    </td>
                    <td className="py-4 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button variant="ghost" size="sm" onClick={() => openEditRuleModal(rule)}>
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="danger" size="sm" onClick={() => handleDeleteRule(rule.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Rule Modal */}
      {showRuleModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white px-6 py-4 border-b border-gray-200 flex items-center justify-between">
              <h2 className="text-xl font-bold text-gray-900">
                {editingRule ? '编辑告警规则' : '新建告警规则'}
              </h2>
              <button onClick={() => setShowRuleModal(false)} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <Input
                label="规则名称"
                value={ruleForm.name}
                onChange={(e) => setRuleForm({ ...ruleForm, name: e.target.value })}
                placeholder="如：暴力破解登录检测"
              />

              <Input
                label="描述"
                value={ruleForm.description}
                onChange={(e) => setRuleForm({ ...ruleForm, description: e.target.value })}
                placeholder="规则用途说明"
              />

              <div className="grid grid-cols-2 gap-4">
                <Select
                  label="规则类型"
                  value={ruleForm.rule_type}
                  onChange={(e) => setRuleForm({ ...ruleForm, rule_type: e.target.value as RuleType })}
                  options={RULE_TYPE_OPTIONS}
                />

                <Select
                  label="严重程度"
                  value={ruleForm.severity}
                  onChange={(e) => setRuleForm({ ...ruleForm, severity: e.target.value as Severity })}
                  options={SEVERITY_OPTIONS}
                />
              </div>

              <Select
                label="数据表"
                value={ruleForm.table_name}
                onChange={(e) => setRuleForm({ ...ruleForm, table_name: e.target.value })}
                options={[
                  { value: '', label: '选择数据表' },
                  ...MOCK_TABLES.map(t => ({ value: t, label: t })),
                ]}
              />

              <div className="grid grid-cols-2 gap-4">
                <Select
                  label="分组字段"
                  value={ruleForm.group_by_field}
                  onChange={(e) => setRuleForm({ ...ruleForm, group_by_field: e.target.value })}
                  options={[
                    { value: '', label: '选择字段' },
                    ...(MOCK_FIELDS[ruleForm.table_name] || []).map(f => ({ value: f, label: f })),
                  ]}
                  disabled={!ruleForm.table_name}
                />

                <Select
                  label="聚合类型"
                  value={ruleForm.aggregation_type}
                  onChange={(e) => setRuleForm({ ...ruleForm, aggregation_type: e.target.value as AggregationType })}
                  options={AGGREGATION_OPTIONS}
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <Select
                  label="运算符"
                  value={ruleForm.operator}
                  onChange={(e) => setRuleForm({ ...ruleForm, operator: e.target.value as Operator })}
                  options={OPERATOR_OPTIONS}
                />

                <Input
                  label="阈值"
                  type="number"
                  value={ruleForm.threshold_value}
                  onChange={(e) => setRuleForm({ ...ruleForm, threshold_value: parseFloat(e.target.value) || 0 })}
                />

                <Input
                  label="时间窗口（分钟）"
                  type="number"
                  value={ruleForm.time_window_minutes}
                  onChange={(e) => setRuleForm({ ...ruleForm, time_window_minutes: parseInt(e.target.value) || 5 })}
                />
              </div>

              <Input
                label="告警内容模板"
                value={ruleForm.alert_template}
                onChange={(e) => setRuleForm({ ...ruleForm, alert_template: e.target.value })}
                placeholder="如：检测到来自 IP {ip_address} 的 {count} 次失败登录"
                helpText="支持的变量：{count}, {value}, {time_window}, {table}, {group_by_field}"
              />

              <div className="pt-4 border-t border-gray-200">
                <Toggle
                  checked={ruleForm.enabled}
                  onChange={(checked) => setRuleForm({ ...ruleForm, enabled: checked })}
                  label="启用规则"
                  description="规则启用后将自动检测告警"
                />
              </div>
            </div>

            <div className="sticky bottom-0 bg-gray-50 px-6 py-4 border-t border-gray-200 flex items-center justify-end gap-3">
              <Button variant="secondary" onClick={() => setShowRuleModal(false)}>
                取消
              </Button>
              <Button onClick={handleSaveRule} variant="success">
                {editingRule ? '保存更改' : '创建规则'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
